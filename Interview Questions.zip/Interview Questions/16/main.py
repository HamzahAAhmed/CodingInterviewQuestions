# @type of arr: list of integers
# @type of element: integer
# @return type: integer
class Solution:
    def findBitonic(self, arr: List[int], element: int) -> int:
        for i in range(len(arr)):
            if arr[i] == element:
                return i

        return -1