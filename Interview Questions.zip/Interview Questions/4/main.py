# @type of k: integer
# @type of n: integer
# @return type: integer
class Solution:
    def calculatePower(self, k: int, n: int) -> int:
    	# write your awesome code here
        return (pow(k,n))