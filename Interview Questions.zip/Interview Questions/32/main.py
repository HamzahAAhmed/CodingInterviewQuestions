# @type of arr: list of integers
# @return type: integer
class Solution:
    def maxWaterTrapped(self, arr: List[int]) -> int:
        getArea = 0
        temp1 = temp2 = 0
        lowerBound = 0
        size = len(arr)-1
        while lowerBound < size:
            if arr[lowerBound] < arr[size]:
                if arr[lowerBound] > temp1:
                    temp1 = arr[lowerBound]
                else:
                    getArea += temp1 - arr[lowerBound]
                lowerBound +=1
            else:
                if arr[size] > temp2:
                    temp2 = arr[size]
                else:
                    getArea += temp2 - arr[size]
                size -=1
        return getArea