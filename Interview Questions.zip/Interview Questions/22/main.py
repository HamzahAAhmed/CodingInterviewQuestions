# @type of arr: list of list of integers
# @return type: integer
import statistics


class Solution:
    def rowMedian(self, arr: List[List[int]]) -> int:
        # write your awesome code here
        emptyArr = []
        for i in arr:
            emptyArr += i
        emptyArr.sort()

        return int((statistics.median(emptyArr)))