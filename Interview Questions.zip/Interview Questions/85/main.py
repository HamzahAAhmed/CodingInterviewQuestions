# @type of arr: a list of integers
# @return type: integer
class Solution:
    def maximumProduct(self, arr: List[int]) -> int:
        # write your awesome code here
        size = len(arr)
        if size < 3:
            return -1

        # will contain max product
        total = -(sys.maxsize - 1)

        for i in range(0, size - 2):
            for j in range(i + 1, size - 1):
                for k in range(j + 1, size):
                    total = max(total, arr[i]* arr[j] * arr[k])

        return total