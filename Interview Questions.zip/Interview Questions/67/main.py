# @type of arr: list of integers
# @return type: Integer
class Solution:
    def findMissingPositive(self, arr: List[int]) -> int:
        myDict = {}

        for i in arr:
            myDict[i] = myDict.get(i, 0) + 1

        for key, value in myDict.items():
            if value > len(arr) / 2:
                return key

        return max(arr)+1