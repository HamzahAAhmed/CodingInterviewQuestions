# @type of num: string
# @return type: string
class Solution:
    def nearestPalindrome(self, num: str) -> str:
        increment = int(num) + 1
        decrement = int(num) - 1

        while (True):

            if (str(increment) == str(increment)[::-1]):
                return increment
            elif (str(decrement) == str(decrement)[::-1]):
                return decrement
            else:
                increment += 1
                decrement -= 1