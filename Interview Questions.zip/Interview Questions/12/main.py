# @type of arr: list of integers
# @return type: list of integers
class Solution:
    def moveZeroes(self, arr: List[int]) -> List[int]:
        zeroes = []
        new = []
        for i in arr:
            if i == 0:
                zeroes.append(0)
            else:
                new.append(i)
        return new + zeroes