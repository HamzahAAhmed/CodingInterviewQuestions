# @type of arr: list of integers
# @return type: int
class Solution:
    def majorityElement(self, arr: List[int]) -> int:
        majority_count = len(arr)//2
        for i in arr:
            count = sum(1 for num in arr if num == i)
            if count > majority_count:
                return i