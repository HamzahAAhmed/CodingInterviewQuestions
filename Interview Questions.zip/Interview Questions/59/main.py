# @type of arr1: list of integers
# @type of arr2: list of integers
# @return type: integer
class Solution:
    def twoArrEqual(self, arr1: List[int], arr2: List[int]) -> int:
        # write your awesome code here
        arr1.sort()
        arr2.sort()

        if arr1 == arr2:
            return 1
        else:
            return 0