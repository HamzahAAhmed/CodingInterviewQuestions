# @type of arr: list of integers
# @type of element: integer
# @return type: integer
class Solution:
    def searchRange(self, arr: List[int], target: int) -> List[int]:
        positions = []
        for i in range(len(arr)):
            if arr[i] == target:
                positions.append(i)

        return [positions[0], positions[-1]]