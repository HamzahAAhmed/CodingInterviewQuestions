# @type of s: string
# @return type: integer
class Solution:
    def firstUniqueChar(self, s: str) -> int:
    	# write your awesome code here
        for i in s:
            if s.count(i) == 1:
                return s.index(i)