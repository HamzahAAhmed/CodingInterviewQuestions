# @type of arr: list of integers
# @return type: integer
class Solution:
    def mostWater(self, arr: List[int]) -> int:
        # write your awesome code here
        lowerBound = 0
        size = len(arr) -1
        area = 0

        while lowerBound < size:

            area = max(area, min(arr[lowerBound], arr[size]) * (size - lowerBound))

            if arr[lowerBound] < arr[size]:
                lowerBound += 1
            else:
                size -= 1
        return area