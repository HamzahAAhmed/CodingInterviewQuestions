def reversal(s):
    return s[::-1]

print(reversal("water"))