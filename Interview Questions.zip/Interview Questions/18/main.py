# @type of arr1: list of integers
# @type of arr2: list of integers
# @return type: int
import statistics
class Solution:
    def medianSortedEqualArray(self, arr1: List[int], arr2: List[int]) -> int:
        newArr = arr1 + arr2

        newArr.sort()
        return int((statistics.median(newArr)))